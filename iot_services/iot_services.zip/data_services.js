var moduleName = 'Data_Services';
var fs = require('fs'); 
var Promise = require("bluebird");
var http = require('https');

var host =  "oicteco-gse00014621.uscom-east-1.oraclecloud.com";
var port = 443;
var autorizacion = "Basic aGVybmFuLmVucmlxdWUuYXltYXJkQG9yYWNsZS5jb206VG9tR29uLjExMDc=";

var Data_Services = function () {
};


Data_Services.prototype.buscarSensor = function (nombre, callback) {
           
           var sensores = {};
           var iSensor = 0;
           var options  = {
             host : host,
             port : port,
             path : '/ic/builder/design/IOTDemo/1.0/resources/data/Sensor', // the rest of the url with parameters if needed
             method : 'GET', 
             headers: {
               "Content-Type": 'application/json',
               "Authorization": autorizacion
             }};   

        var datos = "";
        var req = http.request(options, function(res) {

          res.on('data', function(d) {
              datos += d;
                });

          res.on('end', function(d) {
           
             sensores = JSON.parse(datos);

             if (sensores.items.length > 0) {
               iSensor = sensores.items.find(item => item.nombre === nombre);           
               if (iSensor != null) { 
                  callback(iSensor);
               } else { callback(null);} 
             } else { callback(null);}
             
             
         });
      
          res.on('error', function(e) {
                 console.info('ERROR:\n');
           console.info(e);
                });

        });     
        req.end();

        
}



module.exports = Data_Services;
