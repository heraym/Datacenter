'use strict';

module.exports = {
  components: {
   'iot.datosSensor' : require('./chatbot/datosSensor'),
   'ar.conversador' : require('./chatbot/conversador')
  }
};
