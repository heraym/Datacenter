define([], function() {
  'use strict';

  var StartModule = function StartModule() {};

  return StartModule;
});
